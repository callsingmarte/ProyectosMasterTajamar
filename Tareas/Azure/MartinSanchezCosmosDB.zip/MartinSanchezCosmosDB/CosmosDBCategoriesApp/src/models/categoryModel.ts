export class Category {
    id ?: string = ""
    categoryID ?: string = ""
    categoryName ?: string = ""
    description ?: string = ""
    picture ?: string | undefined = ""
}
