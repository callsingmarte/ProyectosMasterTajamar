export function ValidateForm(data : any) {
    let errors : any = []

    return errors
}