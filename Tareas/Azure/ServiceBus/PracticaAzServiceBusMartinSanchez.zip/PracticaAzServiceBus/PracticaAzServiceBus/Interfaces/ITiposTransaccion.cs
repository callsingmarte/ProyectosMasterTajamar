﻿namespace PracticaAzServiceBus.Interfaces
{
    public interface ITiposTransaccion
    {
        const string PAGO_TARJETA = "PagoConTarjeta";
        const string TRANSFERENCIA_BANCARIA = "TransferenciaBancaria";
    }
}
