﻿namespace PracticaAzServiceBus.Interfaces
{
    public interface IEstadosNotificacion
    {
        const string ENVIADA = "Enviada";
        const string FALLIDA = "Fallida";
    }
}
