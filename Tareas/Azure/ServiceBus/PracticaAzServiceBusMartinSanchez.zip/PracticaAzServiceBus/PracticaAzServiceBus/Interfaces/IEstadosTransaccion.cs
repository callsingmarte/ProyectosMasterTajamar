﻿namespace PracticaAzServiceBus.Interfaces
{
    public interface IEstadosTransaccion
    {
        const string PENDIENTE = "Pendiente";
        const string EXITOSA = "Exitosa";
        const string FALLIDA = "Fallida";
    }
}
