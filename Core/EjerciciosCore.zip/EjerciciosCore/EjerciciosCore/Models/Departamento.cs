﻿namespace EjerciciosCore.Models
{
    public class Departamento
    {
        public int ID { get; set; }
        public string? Nombre { get; set; }
    }
}
